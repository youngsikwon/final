package com.park.uei;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/blockchain")
public class BlockchainController {
	
	@RequestMapping("/transaction")
	public String transaction() {
		return "transaction";
	}
}
