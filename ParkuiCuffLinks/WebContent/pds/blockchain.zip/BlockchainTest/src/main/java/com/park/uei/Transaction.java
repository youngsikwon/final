package com.park.uei;

public class Transaction {

	String from;
	String to;
	int amount;

	public Transaction(String from, String to, int amount) {
		this.from = from;
		this.to = to;
		this.amount = amount;
	}
	
	
}
